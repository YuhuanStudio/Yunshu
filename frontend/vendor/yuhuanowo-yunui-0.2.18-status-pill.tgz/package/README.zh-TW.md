# YunUI

[![npm](https://img.shields.io/npm/v/@yuhuanowo/yunui.svg)](https://www.npmjs.com/package/@yuhuanowo/yunui)
[![showcase & docs](https://img.shields.io/badge/展示與文件-ui.yuhuanstudio.com-111)](https://ui.yuhuanstudio.com)

[English](./README.md) · [简体中文](./README.zh-CN.md) · **繁體中文**

一套不喧嘩的 React 19 + Tailwind v4 設計系統 —— 每個細節都被好好想過。

🔗 **線上展示與文件 → [ui.yuhuanstudio.com](https://ui.yuhuanstudio.com)**

<p align="center">
  <a href="https://ui.yuhuanstudio.com"><img src="https://raw.githubusercontent.com/YuhuanStudio/YunUI/main/assets/hero-light.png" alt="YunUI — 安靜的好看，安靜的扎實" width="100%"></a>
</p>

<p align="center">
  <img src="https://raw.githubusercontent.com/YuhuanStudio/YunUI/main/assets/showcase-light.png" alt="所有 YunUI 元件，盡在一頁" width="49%">
  <img src="https://raw.githubusercontent.com/YuhuanStudio/YunUI/main/assets/hero-dark.png" alt="YunUI 純黑主題" width="49%">
</p>

<p align="center">
  <img src="https://raw.githubusercontent.com/YuhuanStudio/YunUI/main/assets/theming.png" alt="即時主題 — 12 套多色預設、24 套 OKLCH 色盤、權杖驅動特效" width="100%">
</p>

改 YunUI 一處 → 發版 → 各專案升級版本號即可同步取得統一的 **設計 token、動畫、元件**。已在 Yunxin 生產環境使用。

## 誰在使用

YunUI 不是演示專案——它驅動著真實產品：

- **[Yunxin](https://api.yuhuanstudio.com)** —— 統一的 LLM API 閘道，一把金鑰聚合 24+ 家供應商。YunUI 正是從中提取而來，每一個畫面都跑在這些元件上。
- **[Yunshu](https://github.com/YuhuanStudio/Yunshu)** —— 開源的、面向 Apple Silicon 的快速本地多模態推理引擎（原生語音對語音，全部在裝置上運行）。其 web UI 基於 YunUI 打造。

在用 YunUI 打造產品？歡迎提 PR 加到這裡。

---

## 安裝

```bash
npm i @yuhuanowo/yunui      # 或 pnpm add / yarn add
```

要求消費方使用 **React 19** 與 **Tailwind CSS v4**(peerDependencies)。

若匯入 `@yuhuanowo/yunui/content`，也要在應用中安裝此入口靜態匯入的渲染 peer：
`react-markdown`、`remark-gfm`、`remark-math`、`rehype-raw`、`rehype-katex`、
`rehype-slug`、`katex` 和 `shiki`。`mermaid` 會按需載入，只有渲染 Mermaid 圖表時才需要。
`yunui doctor` 會檢查 content 樣式接入，但不會檢查這些渲染 peer 是否能由宿主應用解析；
請透過宿主專案建置驗證。

> 想讓 import 保持短名 `yunui`?用套件別名:
> ```jsonc
> // package.json
> "dependencies": { "yunui": "npm:@yuhuanowo/yunui@^0.2.0" }
> ```
> 之後可用 `import { Button } from "yunui"`。別名安裝時 CSS 也要用
> `yunui/css`，掃描路徑為 `node_modules/yunui/dist`；不會同時安裝 scoped 路徑。
> 下方接入範例使用 canonical 套件名稱。

## Agent 接入

此 checkout 已包含未發布的 agent 接入工具。安裝有提供 CLI 的版本後，透過專案套件管理器執行 `yunui init --css src/app/globals.css`，再跑 `yunui doctor --strict` 與 `yunui audit --strict`。目前可用 `node scripts/yunui-cli.mjs` 測試。初始化會保留既有 AGENTS.md／CLAUDE.md，加入 Codex／Claude 專案 skills，並計算正確的別名與 CSS 相對掃描路徑。

用 `yunui find`／`yunui info` 查實際匯出、props 與 installed declarations；`agent/recipes/` 提供直接 import 的 landing、dashboard、chat 組合。Doctor 檢查接入，audit 檢查控制項來源與疑似重製 UI；仍需 host build、人工來源審查與渲染驗證。

## 接入(3 步)

### 1. 引入設計系統樣式

在全域 CSS(如 `app/globals.css`):

```css
@import "tailwindcss";
@import "@yuhuanowo/yunui/css";

/* 關鍵:讓 Tailwind v4 掃描 YunUI 產物裡的內聯工具類,否則元件會「沒樣式」 */
@source "../node_modules/@yuhuanowo/yunui/dist";
```

> `@source` 路徑以該 CSS 檔為基準,依你的專案結構調整。字型(Geist / JetBrains Mono)不打包,由消費方自行載入。

### 2. 用元件

```tsx
import { Button, Card, Dialog, DialogContent } from "@yuhuanowo/yunui";

export function Demo() {
  return (
    <Card hover className="p-6">
      <Button variant="primary">Hello YunUI</Button>
    </Card>
  );
}
```

### 3.(可選)注入框架轉接器

部分元件需要路由 / 圖片 / i18n。在根佈局用 `YunUIProvider` 注入你框架的實作:

```tsx
import { YunUIProvider } from "@yuhuanowo/yunui/adapters";
import Link from "next/link";
import Image from "next/image";
import { useRouter } from "next/navigation";
import { useTranslations } from "next-intl";

<YunUIProvider
  adapters={{
    Link,
    Image,
    useRouter,
    useT: (ns) => useTranslations(ns),
  }}
>
  {children}
</YunUIProvider>;
```

不注入時,YunUI 使用零相依預設實作(`<a>` / `<img>` / identity 翻譯)。

---

## 入口

| 入口 | 內容 |
| --- | --- |
| `@yuhuanowo/yunui` | 原子元件:Button / IconButton / Input / Textarea / Card / Badge / Dialog / Select / Slider / Progress / Tabs / Avatar / Tooltip / DropdownMenu / Skeleton / Spinner / PageLoader / EmptyState / Label,佈局原語 Flex / Grid / Row / Column / Stack,資料展示 Table / Breadcrumb / Pagination,互動元件 Accordion / RadioGroup / Switch / Checkbox / Combobox / CustomSelect / SegmentedSelect / NavTabs / Collapsible / Popover / Modal / Sheet / ConfirmModal / ThemeToggle,以及 ShinyButton / Marquee / BentoGrid / AnimatedNumber 與 MotionDiv·fadeIn·stagger 等動畫預設 |
| `@yuhuanowo/yunui/css` | 設計系統樣式(token 變數、`@theme` 對應、`.btn`/`.card`/`.glass` 等全域類別、動畫 keyframes) |
| `@yuhuanowo/yunui/adapters` | `YunUIProvider` / `useYunUI` 與轉接器介面 |
| `@yuhuanowo/yunui/patterns` | 頁面級元件:FAQ、StatCard(`tone`/`inline`/`valueFirst` 變體)、BlogCard、CodeBlock、Sidebar、PageHeader、BackgroundEffects 等 |
| `@yuhuanowo/yunui/content` | 內容渲染元件：`MarkdownRenderer`（GFM + KaTeX + Shiki + Mermaid + 提示框 + 惰性縮放圖片）、`CodeBlock` / `InlineCode`、`CalloutBlock`、`MathRenderer`、`MermaidDiagram`、`ContentImage`、`ImageLightbox`。需安裝上文列出的靜態渲染 peer；Mermaid 按需載入。未知程式語言會回退為跳脫後的純文字。 |
| `@yuhuanowo/yunui/chat` | 插槽式聊天 UI：`ChatMessage`、`ChatMessageList`、`ChatComposer`、`ChatHeader`、`StreamingText`、`ContextCards` |
| `@yuhuanowo/yunui/ai` | AI 產品域元件(prop 驅動,無 API 直連):ProviderIcon / ModelIcon / ModelTypeIcon、ModelCard、CapabilitySelector、Navbar、Footer、LanguageSwitcher、ThinkingBlock、SelectionActions、DiffTable、IDBadge … |

**工具 / hooks**(從 `@yuhuanowo/yunui` 匯出):`cn`、`toast` / `Toaster`(基於 sonner)、`MotionDiv` / `MotionSpan` / `fadeIn` / `staggerContainer` / `staggerItem`、`useEscapeKey` / `useBodyScrollLock` / `useModalBehavior`。

> **`yunui/ai` 圖示素材隨 npm 套件發佈於 `icons/`，但不在 JavaScript bundle 中；預設透過 jsDelivr 提供。** `ProviderIcon` / `ModelIcon` / `ModelAvatar` / `ModelCard` 從 `iconBasePath` 下的 `/providers/*.png`、`/models/*.png` 載入圖示，預設使用 `https://cdn.jsdelivr.net/npm/@yuhuanowo/yunui@0.2/icons`。消費方也可自行託管套件內的 `icons/` 並設定 `<YunUIProvider adapters={{ iconBasePath: "/icons" }}>`。單個自訂圖示 URL 透過元件 `iconUrl` prop 傳入,原樣使用。
>
> 同樣,`./_deferred/ai-search`(文件 AI 搜尋)**未匯出** —— 它綁定 `@ai-sdk/react` + 聊天堆疊,是產品功能而非通用元件,匯出會給函式庫強加 ai-sdk peer 相依。

---

Markdown 渲染器會清理原始 HTML，同時保留支援的 GFM 功能；危險元素和屬性會被移除，改寫後的 URL 也會經過安全協定過濾。這是輸入清理措施，不代表任意內容都絕對安全。另外，Markdown 渲染器可選接收 `linkOrigin`，讓 SSR 與瀏覽器以相同 origin 判斷絕對連結是否站內。不傳時，絕對 HTTP(S) 與協定相對連結視為外連，相對連結仍視為站內。`ImageLightbox` 可用 `label` 設定無障礙名稱（預設取圖片 alt 或內容翻譯）；它會限制焦點、宣告模態對話框並鎖定背景捲動。

## 主題

三套主題,透過根元素 class 切換(配合 `next-themes`):`light`(預設 `:root`)、`.dark`、`.true-black`(OLED)。

## 同步流程(改一處,各專案同步)

```bash
# 在 YunUI:改程式碼 → 升 package.json 版本號 → 提交
git tag v0.2.0 && git push origin v0.2.0
# ↑ 推 tag 觸發 GitHub Actions:typecheck → test → build → npm publish
#   (tokenless OIDC trusted publishing + provenance,無需本地發佈/OTP)

# 在消費專案:
pnpm up @yuhuanowo/yunui
```

> 發佈走 GitHub Actions(`.github/workflows/release.yml`)。一次性設定:在
> npmjs.com 的套件 Settings → Trusted Publisher 裡新增 GitHub Actions
> (repo `YuhuanStudio/YunUI`,workflow `release.yml`)。**不需要任何 npm token。**

## 開發

```bash
pnpm install
pnpm dev        # tsup watch(配合 site/ 即時預覽)
pnpm build      # 產出 dist/
pnpm typecheck
pnpm test
```

展示站在 `site/`(Next 16 + Tailwind v4):`pnpm --filter yunui-site dev`。

## 貢獻 / 加新元件

完整規範見 **[CONTRIBUTING.md](./CONTRIBUTING.md)**。最容易踩的一條:**元件不內建文案 / 不綁定 i18n 函式庫**。需要顯示文字的元件必須走 adapter,不要 import next-intl,也不要硬寫字串:

```tsx
import { useYunUI } from "../adapters/context";

export function Thing() {
  const t = useYunUI().useT("thing");   // 命名空間
  return <button>{t("submit")}</button>; // key,不是字面量
}
```

- 不注入 provider 時 `useT` 直接回傳 key(元件照樣渲染,展示站也是這樣跑的)。
- 真正的翻譯文案加到**消費方**(如 Yunxin `messages/{en,zh-CN,zh-TW}.json`),不放 YunUI。
- 同理:路由/圖片走 `useYunUI().Link/Image/useRouter`(別用 `next/*`);業務資料走 **props**(別在元件裡 `useBranding`/`fetch`/`localStorage`)。

## License

Apache-2.0 © YuhuanStudio
