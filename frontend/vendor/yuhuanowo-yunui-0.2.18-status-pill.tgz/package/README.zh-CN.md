# YunUI

[![npm](https://img.shields.io/npm/v/@yuhuanowo/yunui.svg)](https://www.npmjs.com/package/@yuhuanowo/yunui)
[![showcase & docs](https://img.shields.io/badge/展示与文档-ui.yuhuanstudio.com-111)](https://ui.yuhuanstudio.com)

[English](./README.md) · **简体中文** · [繁體中文](./README.zh-TW.md)

一套不喧哗的 React 19 + Tailwind v4 设计系统 —— 每个细节都被好好想过。

🔗 **在线展示与文档 → [ui.yuhuanstudio.com](https://ui.yuhuanstudio.com)**

<p align="center">
  <a href="https://ui.yuhuanstudio.com"><img src="https://raw.githubusercontent.com/YuhuanStudio/YunUI/main/assets/hero-light.png" alt="YunUI — 安静的好看，安静的扎实" width="100%"></a>
</p>

<p align="center">
  <img src="https://raw.githubusercontent.com/YuhuanStudio/YunUI/main/assets/showcase-light.png" alt="所有 YunUI 组件，尽在一页" width="49%">
  <img src="https://raw.githubusercontent.com/YuhuanStudio/YunUI/main/assets/hero-dark.png" alt="YunUI 纯黑主题" width="49%">
</p>

<p align="center">
  <img src="https://raw.githubusercontent.com/YuhuanStudio/YunUI/main/assets/theming.png" alt="即时主题 — 12 套多色预设、24 套 OKLCH 色盘、令牌驱动特效" width="100%">
</p>

改 YunUI 一处 → 发版 → 各项目升级版本号即可同步获得统一的 **设计 token、动画、组件**。已在 Yunxin 生产环境使用。

## 谁在使用

YunUI 不是演示项目——它驱动着真实产品：

- **[Yunxin](https://api.yuhuanstudio.com)** —— 统一的 LLM API 网关，一把密钥聚合 24+ 家供应商。YunUI 正是从中提取而来，每一个界面都跑在这些组件上。
- **[Yunshu](https://github.com/YuhuanStudio/Yunshu)** —— 开源的、面向 Apple Silicon 的快速本地多模态推理引擎（原生语音对语音，全部在设备上运行）。其 web UI 基于 YunUI 构建。

在用 YunUI 构建产品？欢迎提 PR 加到这里。

---

## 安装

```bash
npm i @yuhuanowo/yunui      # 或 pnpm add / yarn add
```

要求消费方使用 **React 19** 与 **Tailwind CSS v4**(peerDependencies)。

如果导入 `@yuhuanowo/yunui/content`，还需在应用中安装该入口静态导入的渲染 peer：
`react-markdown`、`remark-gfm`、`remark-math`、`rehype-raw`、`rehype-katex`、
`rehype-slug`、`katex` 和 `shiki`。`mermaid` 按需加载，只有渲染 Mermaid 图表时才需要。
`yunui doctor` 会检查 content 样式接入，但不会检查这些渲染 peer 能否由宿主应用解析；
请通过宿主项目构建验证。

> 想让 import 保持短名 `yunui`?用包别名:
> ```jsonc
> // package.json
> "dependencies": { "yunui": "npm:@yuhuanowo/yunui@^0.2.0" }
> ```
> 之后可用 `import { Button } from "yunui"`。别名安装时 CSS 也要用
> `yunui/css`，扫描路径为 `node_modules/yunui/dist`；不会同时安装 scoped 路径。
> 下方接入示例使用 canonical 包名。

## Agent 接入

此 checkout 已包含未发布的 agent 接入工具。安装提供 CLI 的版本后，通过项目包管理器执行 `yunui init --css src/app/globals.css`，再运行 `yunui doctor --strict` 和 `yunui audit --strict`。目前可用 `node scripts/yunui-cli.mjs` 测试。初始化保留现有 AGENTS.md／CLAUDE.md，加入 Codex／Claude 项目 skills，并计算正确的别名与 CSS 相对扫描路径。

用 `yunui find`／`yunui info` 查询实际导出、props 和 installed declarations；`agent/recipes/` 提供直接 import 的 landing、dashboard、chat 组合。Doctor 检查接入，audit 检查控件来源和疑似重写 UI；仍需 host build、人工来源审查和渲染验证。

## 接入(3 步)

### 1. 引入设计系统样式

在全局 CSS(如 `app/globals.css`):

```css
@import "tailwindcss";
@import "@yuhuanowo/yunui/css";

/* 关键:让 Tailwind v4 扫描 YunUI 产物里的内联工具类,否则组件会"没样式" */
@source "../node_modules/@yuhuanowo/yunui/dist";
```

> `@source` 路径以该 CSS 文件为基准,按你的项目结构调整。字体(Geist / JetBrains Mono)不打包,由消费方自行加载。

### 2. 用组件

```tsx
import { Button, Card, Dialog, DialogContent } from "@yuhuanowo/yunui";

export function Demo() {
  return (
    <Card hover className="p-6">
      <Button variant="primary">Hello YunUI</Button>
    </Card>
  );
}
```

### 3.(可选)注入框架适配器

部分组件需要路由 / 图片 / i18n。在根布局用 `YunUIProvider` 注入你框架的实现:

```tsx
import { YunUIProvider } from "@yuhuanowo/yunui/adapters";
import Link from "next/link";
import Image from "next/image";
import { useRouter } from "next/navigation";
import { useTranslations } from "next-intl";

<YunUIProvider
  adapters={{
    Link,
    Image,
    useRouter,
    useT: (ns) => useTranslations(ns),
  }}
>
  {children}
</YunUIProvider>;
```

不注入时,YunUI 使用零依赖默认实现(`<a>` / `<img>` / identity 翻译)。

---

## 入口

| 入口 | 内容 |
| --- | --- |
| `@yuhuanowo/yunui` | 原子组件:Button / IconButton / Input / Textarea / Card / Badge / Dialog / Select / Slider / Progress / Tabs / Avatar / Tooltip / DropdownMenu / Skeleton / Spinner / PageLoader / EmptyState / Label,布局原语 Flex / Grid / Row / Column / Stack,数据展示 Table / Breadcrumb / Pagination,交互组件 Accordion / RadioGroup / Switch / Checkbox / Combobox / CustomSelect / SegmentedSelect / NavTabs / Collapsible / Popover / Modal / Sheet / ConfirmModal / ThemeToggle,以及 ShinyButton / Marquee / BentoGrid / AnimatedNumber 与 MotionDiv·fadeIn·stagger 等动画预设 |
| `@yuhuanowo/yunui/css` | 设计系统样式(token 变量、`@theme` 映射、`.btn`/`.card`/`.glass` 等全局类、动画 keyframes) |
| `@yuhuanowo/yunui/adapters` | `YunUIProvider` / `useYunUI` 与适配器接口 |
| `@yuhuanowo/yunui/patterns` | 页面级组件:FAQ、StatCard(`tone`/`inline`/`valueFirst` 变体)、BlogCard、CodeBlock、Sidebar、PageHeader、BackgroundEffects 等 |
| `@yuhuanowo/yunui/content` | 内容渲染组件：`MarkdownRenderer`（GFM + KaTeX + Shiki + Mermaid + 提示框 + 惰性缩放图片）、`CodeBlock` / `InlineCode`、`CalloutBlock`、`MathRenderer`、`MermaidDiagram`、`ContentImage`、`ImageLightbox`。需安装上文列出的静态渲染 peer；Mermaid 按需加载。未知代码语言会回退为转义后的纯文本。 |
| `@yuhuanowo/yunui/chat` | 插槽式聊天 UI：`ChatMessage`、`ChatMessageList`、`ChatComposer`、`ChatHeader`、`StreamingText`、`ContextCards` |
| `@yuhuanowo/yunui/ai` | AI 产品域组件(prop 驱动,无 API 直连):ProviderIcon / ModelIcon / ModelTypeIcon、ModelCard、CapabilitySelector、Navbar、Footer、LanguageSwitcher、ThinkingBlock、SelectionActions、DiffTable、IDBadge … |

**工具 / hooks**(从 `@yuhuanowo/yunui` 导出):`cn`、`toast` / `Toaster`(基于 sonner)、`MotionDiv` / `MotionSpan` / `fadeIn` / `staggerContainer` / `staggerItem`、`useEscapeKey` / `useBodyScrollLock` / `useModalBehavior`。

> **`yunui/ai` 图标素材随 npm 包发布在 `icons/`，但不在 JavaScript bundle 中；默认通过 jsDelivr 提供。** `ProviderIcon` / `ModelIcon` / `ModelAvatar` / `ModelCard` 从 `iconBasePath` 下的 `/providers/*.png`、`/models/*.png` 加载图标，默认使用 `https://cdn.jsdelivr.net/npm/@yuhuanowo/yunui@0.2/icons`。消费方也可自行托管包内的 `icons/` 并配置 `<YunUIProvider adapters={{ iconBasePath: "/icons" }}>`。单个自定义图标 URL 通过组件 `iconUrl` prop 传入,原样使用。
>
> 同样,`./_deferred/ai-search`(文档 AI 搜索)**未导出** —— 它绑定 `@ai-sdk/react` + 聊天栈,是产品功能而非通用组件,导出会给库强加 ai-sdk peer 依赖。

---

Markdown 渲染器会清理原始 HTML，同时保留受支持的 GFM 功能；危险元素和属性会被移除，改写后的 URL 也会经过安全协议过滤。这是输入清理措施，不代表任意内容都绝对安全。另外，Markdown 渲染器可选接收 `linkOrigin`，让 SSR 与浏览器以相同 origin 判断绝对链接是否站内。不传时，绝对 HTTP(S) 与协议相对链接视为外链，相对链接仍视为站内。`ImageLightbox` 可用 `label` 设置无障碍名称（默认取图片 alt 或内容翻译）；它会限制焦点、声明模态对话框并锁定背景滚动。

## 主题

三套主题,通过根元素 class 切换(配合 `next-themes`):`light`(默认 `:root`)、`.dark`、`.true-black`(OLED)。

## 同步流程(改一处,各项目同步)

```bash
# 在 YunUI:改代码 → 升 package.json 版本号 → 提交
git tag v0.2.0 && git push origin v0.2.0
# ↑ 推 tag 触发 GitHub Actions:typecheck → test → build → npm publish
#   (tokenless OIDC trusted publishing + provenance,无需本地发布/OTP)

# 在消费项目:
pnpm up @yuhuanowo/yunui
```

> 发布走 GitHub Actions(`.github/workflows/release.yml`)。一次性设置:在
> npmjs.com 的包 Settings → Trusted Publisher 里添加 GitHub Actions
> (repo `YuhuanStudio/YunUI`,workflow `release.yml`)。**不需要任何 npm token。**

## 开发

```bash
pnpm install
pnpm dev        # tsup watch(配合 site/ 实时预览)
pnpm build      # 产出 dist/
pnpm typecheck
pnpm test
```

展示站在 `site/`(Next 16 + Tailwind v4):`pnpm --filter yunui-site dev`。

## 贡献 / 加新组件

完整规范见 **[CONTRIBUTING.md](./CONTRIBUTING.md)**。最容易踩的一条:**组件不内置文案 / 不绑定 i18n 库**。需要显示文字的组件必须走 adapter,不要 import next-intl,也不要硬写字符串:

```tsx
import { useYunUI } from "../adapters/context";

export function Thing() {
  const t = useYunUI().useT("thing");   // 命名空间
  return <button>{t("submit")}</button>; // key,不是字面量
}
```

- 不注入 provider 时 `useT` 直接返回 key(组件照样渲染,展示站也是这样跑的)。
- 真正的翻译文案加到**消费方**(如 Yunxin `messages/{en,zh-CN,zh-TW}.json`),不放 YunUI。
- 同理:路由/图片走 `useYunUI().Link/Image/useRouter`(别用 `next/*`);业务数据走 **props**(别在组件里 `useBranding`/`fetch`/`localStorage`)。

## License

Apache-2.0 © YuhuanStudio
